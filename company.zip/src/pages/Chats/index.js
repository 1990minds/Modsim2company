import React from 'react'
import Layout from '../../components/layout/Main'

const Index = () => {
  return (
    <Layout>
        Updating soon
    </Layout>
  )
}

export default Index
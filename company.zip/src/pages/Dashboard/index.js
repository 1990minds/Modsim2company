import React from 'react'
import Home from './Home'
import Layout from '../../components/layout/Main'

function Index() {
  return (
    <Layout>
        <Home />
    </Layout>
  )
}

export default Index